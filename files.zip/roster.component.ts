import { Component, computed, inject, linkedSignal } from '@angular/core';
import {
  AVAILABILITY_LABELS,
  Assistant,
  Availability,
  Slot,
  WEEKDAY_SHORT,
  Weekday,
  formatHour,
  slotKey,
} from '../models/schedule.model';
import { ScheduleStore } from '../services/schedule-store.service';

interface Candidate {
  assistant: Assistant;
  answer: Availability | undefined;
  assigned: boolean;
}

@Component({
  selector: 'app-roster',
  templateUrl: './roster.component.html',
  styleUrl: './roster.component.css',
})
export class RosterComponent {
  readonly store = inject(ScheduleStore);
  /** Fällt automatisch auf null zurück, wenn der gewählte Slot aus dem Raster fällt. */
  readonly selectedKey = linkedSignal<Slot[], string | null>({
    source: this.store.slots,
    computation: (slots, previous) => {
      const previousKey = previous?.value;
      return previousKey && slots.some((s) => s.key === previousKey) ? previousKey : null;
    },
  });

  readonly selectedSlotLabel = computed(() => {
    const key = this.selectedKey();
    const slot = this.store.slots().find((s) => s.key === key);
    if (!slot) return null;
    return WEEKDAY_SHORT[slot.weekday] + ' ' + this.time(slot.hour);
  });

  /** Kandidaten nach Verfügbarkeit sortiert: Ja zuerst, Nein zuletzt. */
  readonly candidates = computed<Candidate[]>(() => {
    const key = this.selectedKey();
    if (!key) return [];
    const rank: Record<string, number> = { yes: 0, ifNeeded: 1, undefined: 2, no: 3 };
    return this.store
      .assistants()
      .map((assistant) => ({
        assistant,
        answer: this.store.getAvailability(assistant.id, key),
        assigned: this.store.isAssigned(key, assistant.id),
      }))
      .sort((a, b) => rank[String(a.answer)] - rank[String(b.answer)]);
  });

  short(weekday: Weekday): string {
    return WEEKDAY_SHORT[weekday];
  }

  time(hour: number): string {
    return formatHour(hour) + '–' + formatHour(hour + 1);
  }

  key(weekday: Weekday, hour: number): string {
    return slotKey(weekday, hour);
  }

  isOpen(weekday: Weekday, hour: number): boolean {
    const day = this.store.openingHours().find((o) => o.weekday === weekday);
    return !!day?.open && hour >= day.start && hour < day.end;
  }

  assignedFor(weekday: Weekday, hour: number): Assistant[] {
    const ids = this.store.assignedTo(slotKey(weekday, hour));
    const assistants = this.store.assistants();
    return ids
      .map((id) => assistants.find((a) => a.id === id))
      .filter((a): a is Assistant => !!a);
  }

  levelFor(weekday: Weekday, hour: number): string | null {
    const list = this.store.warningsBySlot().get(slotKey(weekday, hour));
    if (!list?.length) return null;
    if (list.some((w) => w.level === 'error')) return 'error';
    return list[0].level;
  }

  answerLabel(answer: Availability | undefined): string {
    if (!answer) return 'keine Antwort';
    if (answer === 'ifNeeded') return 'notfalls';
    return AVAILABILITY_LABELS[answer].toLowerCase();
  }

  select(weekday: Weekday, hour: number): void {
    this.selectedKey.set(slotKey(weekday, hour));
  }

  toggle(assistantId: string): void {
    const key = this.selectedKey();
    if (key) this.store.toggleAssignment(key, assistantId);
  }

  clearAll(): void {
    if (confirm('Alle Einteilungen löschen? Verfügbarkeiten bleiben erhalten.')) {
      this.store.clearAssignments();
    }
  }
}

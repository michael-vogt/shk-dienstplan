import { Component, inject, linkedSignal } from '@angular/core';
import {
  AVAILABILITY_LABELS,
  Assistant,
  Availability,
  WEEKDAY_SHORT,
  Weekday,
  formatHour,
  slotKey,
} from '../models/schedule.model';
import { ScheduleStore } from '../services/schedule-store.service';

@Component({
  selector: 'app-availability',
  templateUrl: './availability.component.html',
  styleUrl: './availability.component.css',
})
export class AvailabilityComponent {
  readonly store = inject(ScheduleStore);

  /**
   * Schreibbar wie ein signal, folgt aber der Liste: verschwindet die gewählte
   * Hilfskraft, rückt automatisch die erste nach.
   */
  readonly selectedId = linkedSignal<Assistant[], string | null>({
    source: this.store.assistants,
    computation: (assistants, previous) => {
      const previousId = previous?.value;
      if (previousId && assistants.some((a) => a.id === previousId)) return previousId;
      return assistants[0]?.id ?? null;
    },
  });

  short(weekday: Weekday): string {
    return WEEKDAY_SHORT[weekday];
  }

  time(hour: number): string {
    return formatHour(hour) + '–' + formatHour(hour + 1);
  }

  isOpen(weekday: Weekday, hour: number): boolean {
    const day = this.store.openingHours().find((o) => o.weekday === weekday);
    return !!day?.open && hour >= day.start && hour < day.end;
  }

  answer(weekday: Weekday, hour: number): Availability | undefined {
    const id = this.selectedId();
    if (!id) return undefined;
    return this.store.getAvailability(id, slotKey(weekday, hour));
  }

  cellLabel(weekday: Weekday, hour: number): string {
    const value = this.answer(weekday, hour);
    if (value === 'yes') return 'Ja';
    if (value === 'ifNeeded') return 'Notfalls';
    if (value === 'no') return 'Nein';
    return '';
  }

  cellTitle(weekday: Weekday, hour: number): string {
    const value = this.answer(weekday, hour);
    const label = value ? AVAILABILITY_LABELS[value] : 'Noch nicht beantwortet';
    return WEEKDAY_SHORT[weekday] + ' ' + this.time(hour) + ': ' + label;
  }

  answeredCount(assistantId: string): number {
    return this.store.slots().filter((s) => this.store.getAvailability(assistantId, s.key)).length;
  }

  cycle(weekday: Weekday, hour: number): void {
    const id = this.selectedId();
    if (id) this.store.cycleAvailability(id, slotKey(weekday, hour));
  }

  setAll(value: Availability | undefined): void {
    const id = this.selectedId();
    if (!id) return;
    this.store.setAvailabilityForSlots(
      id,
      this.store.slots().map((s) => s.key),
      value,
    );
  }

  setColumn(weekday: Weekday, value: Availability): void {
    const id = this.selectedId();
    if (!id) return;
    this.store.setAvailabilityForSlots(
      id,
      this.store
        .slots()
        .filter((s) => s.weekday === weekday)
        .map((s) => s.key),
      value,
    );
  }

  add(input: HTMLInputElement): void {
    this.store.addAssistant(input.value);
    input.value = '';
    const created = this.store.assistants().at(-1);
    if (created) this.selectedId.set(created.id);
  }

  remove(id: string, name: string): void {
    if (confirm(name + ' entfernen? Verfügbarkeiten und Einteilungen gehen dabei verloren.')) {
      this.store.removeAssistant(id);
    }
  }
}

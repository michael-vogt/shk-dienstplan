import { Component, inject } from '@angular/core';
import { WEEKDAY_LABELS, Weekday, formatHour } from '../models/schedule.model';
import { ScheduleStore } from '../services/schedule-store.service';

@Component({
  selector: 'app-opening-hours',
  templateUrl: './opening-hours.component.html',
  styleUrl: './opening-hours.component.css',
})
export class OpeningHoursComponent {
  readonly store = inject(ScheduleStore);
  readonly formatHour = formatHour;

  label(weekday: Weekday): string {
    return WEEKDAY_LABELS[weekday];
  }

  setOpen(weekday: Weekday, event: Event): void {
    this.store.setOpeningHours(weekday, {
      open: (event.target as HTMLInputElement).checked,
    });
  }

  setStart(weekday: Weekday, event: Event): void {
    this.store.setOpeningHours(weekday, {
      start: Number((event.target as HTMLInputElement).value),
    });
  }

  setEnd(weekday: Weekday, event: Event): void {
    this.store.setOpeningHours(weekday, {
      end: Number((event.target as HTMLInputElement).value),
    });
  }
}
